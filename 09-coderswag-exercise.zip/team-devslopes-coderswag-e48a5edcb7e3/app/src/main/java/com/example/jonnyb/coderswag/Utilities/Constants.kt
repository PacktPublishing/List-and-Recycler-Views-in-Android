package com.example.jonnyb.coderswag.Utilities

/**
 * Created by jonnyb on 8/23/17.
 */

const val EXTRA_CATEGORY = "category"
const val EXTRA_PRODUCT = "product"