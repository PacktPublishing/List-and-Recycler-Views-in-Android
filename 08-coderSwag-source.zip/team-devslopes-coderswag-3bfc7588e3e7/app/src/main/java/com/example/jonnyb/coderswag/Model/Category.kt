package com.example.jonnyb.coderswag.Model

/**
 * Created by jonnyb on 8/21/17.
 */
class Category(val title: String, val image: String) {
    override fun toString(): String {
        return title
    }
}