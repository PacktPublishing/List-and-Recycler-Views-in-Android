package com.example.jonnyb.coderswag.Model

/**
 * Created by jonnyb on 8/21/17.
 */
class Product(val title: String, val price: String, val image: String)